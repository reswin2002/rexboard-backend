const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const axios = require('axios'); // Added for DeepSeek API

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Configuration
const PORT = process.env.PORT || 5000;

// Mock database
let designs = {};

// API Routes
app.post('/api/generate', async (req, res) => {
  const { prompt } = req.body;
  
  const systemMessage = `
  You are REX, an AI PCB design assistant. The user will describe what they want in their PCB design.
  Your task is to:
  1. Identify all electronic components needed
  2. Determine how they should be connected
  3. Suggest optimal placement
  4. Consider power requirements
  5. Ensure the design follows best practices
  
  Respond with JSON format containing:
  - components: array of {name, type, package, pins}
  - connections: array of {from, to, type}
  - notes: any important design considerations
  `;

  try {
    // DeepSeek API Call
    const response = await axios.post(
      'https://api.deepseek.com/v1/chat/completions',
      {
        model: "deepseek-chat",
        messages: [
          { role: "system", content: systemMessage },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${process.env.DEEPSEEK_API_KEY}`
        }
      }
    );

    const design = response.data.choices[0].message.content;
    design.id = Date.now();
    designs[design.id] = design;
    
    res.json({ success: true, design });
  } catch (error) {
    console.error("DeepSeek API Error:", error.response?.data || error.message);
    res.status(500).json({ success: false, error: 'AI processing failed' });
  }
});

// Wiring Endpoint
app.post('/api/wiring', async (req, res) => {
  const { designId, layer } = req.body;
  const design = designs[designId];
  
  if (!design) {
    return res.status(404).json({ success: false, error: 'Design not found' });
  }

  try {
    const wiring = generateWiring(design, layer);
    res.json({ success: true, wiring });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, error: 'Wiring generation failed' });
  }
});

// Helper Functions
function generateWiring(design, layer) {
  return {
    layers: layer === 'auto' ? 2 : parseInt(layer),
    traces: design.connections.map(conn => ({
      from: conn.from,
      to: conn.to,
      path: generatePath(conn.from, conn.to),
      width: conn.type === 'power' ? 0.5 : 0.2
    }))
  };
}

function generatePath(from, to) {
  return [
    { x: 0, y: 0 },
    { x: 1, y: 1 },
    { x: 2, y: 1 },
    { x: 3, y: 0 }
  ];
}

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});